package thecodetechforge;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

public class Archivo {

    private int id_mu;
    private String full_name_mu;
    private String email_mu;
    private String phone_mu;
    private java.util.Date birth_date_mu;
    private java.util.Date import_date_mu;

    // Constructor vacío
    public Archivo() {}

    // Constructor con parámetros (opcional)
    public Archivo(int id_mu, String full_name_mu, String email_mu, String phone_mu, java.util.Date birth_date_mu, java.util.Date import_date_mu) {
        this.id_mu = id_mu;
        this.full_name_mu = full_name_mu;
        this.email_mu = email_mu;
        this.phone_mu = phone_mu;
        this.birth_date_mu = birth_date_mu;
        this.import_date_mu = import_date_mu;
    }

    // Getters y Setters
    public int getId_mu() {
        return id_mu;
    }

    public void setId_mu(int id_mu) {
        this.id_mu = id_mu;
    }

    public String getFull_name_mu() {
        return full_name_mu;
    }

    public void setFull_name_mu(String full_name_mu) {
        this.full_name_mu = full_name_mu;
    }

    public String getEmail_mu() {
        return email_mu;
    }

    public void setEmail_mu(String email_mu) {
        this.email_mu = email_mu;
    }

    public String getPhone_mu() {
        return phone_mu;
    }

    public void setPhone_mu(String phone_mu) {
        this.phone_mu = phone_mu;
    }

    public java.util.Date getBirth_date_mu() {
        return birth_date_mu;
    }

    public void setBirth_date_mu(java.util.Date birth_date_mu) {
        this.birth_date_mu = birth_date_mu;
    }

    public java.util.Date getImport_date_mu() {
        return import_date_mu;
    }

    public void setImport_date_mu(java.util.Date import_date_mu) {
        this.import_date_mu = import_date_mu;
    }

    // Método para importar datos desde un archivo CSV a la tabla migrated_users
    public static void importarDesdeCSV(File archivo) throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader(archivo));
             Connection conn = DBConnection.getConnection()) {

            conn.setAutoCommit(false);

            String sql = "INSERT INTO migrated_users (id_mu, full_name_mu, email_mu, phone_mu, birth_date_mu, import_date_mu) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);

            // Saltar encabezado del CSV
            br.readLine();

            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");

            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length >= 6) {
                    try {
                        ps.setInt(1, Integer.parseInt(datos[0].trim()));
                        ps.setString(2, datos[1].trim());
                        ps.setString(3, datos[2].trim());
                        ps.setString(4, datos[3].trim());

                        java.util.Date birthDate = formatoFecha.parse(datos[4].trim());
                        ps.setDate(5, new java.sql.Date(birthDate.getTime()));

                        java.util.Date importDate = formatoFecha.parse(datos[5].trim());
                        ps.setDate(6, new java.sql.Date(importDate.getTime()));

                        ps.addBatch();
                    } catch (Exception ex) {
                        System.out.println("Error en linea: " + linea);
                    }
                }
            }

            ps.executeBatch();
            conn.commit();
            ps.close();
        }
    }
}
