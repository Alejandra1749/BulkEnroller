package thecodetechforge;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class GestorArchivosFrame extends JFrame {

    private JTable table;
    private DefaultTableModel model;

    public GestorArchivosFrame() {
        setTitle("BulkEnroller - Mis Archivos");
        setSize(850, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(0, 70, 140));
        JLabel title = new JLabel("  Mis Archivos", JLabel.LEFT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        topPanel.add(title, BorderLayout.CENTER);

        JButton btnCargarArchivo = new JButton("Cargar archivo CSV");
        btnCargarArchivo.setBackground(new Color(30, 144, 255));
        btnCargarArchivo.setForeground(Color.WHITE);
        btnCargarArchivo.setFocusPainted(false);
        btnCargarArchivo.addActionListener(e -> seleccionarYSubirArchivo());
        topPanel.add(btnCargarArchivo, BorderLayout.EAST);

        model = new DefaultTableModel(new Object[]{
            "Nombre", "Fecha de Carga", "Estado", "Acciones"
        }, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setRowHeight(35);
        JScrollPane scrollPane = new JScrollPane(table);

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        add(mainPanel);

        cargarArchivosDesdeBD();
    }

    private void seleccionarYSubirArchivo() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            String nombreArchivo = archivo.getName();
            java.sql.Date fechaHoy = new java.sql.Date(System.currentTimeMillis());

            try (Connection conn = DBConnection.getConnection()) {
                conn.setAutoCommit(false);

                // Validar si ya existe
                PreparedStatement check = conn.prepareStatement("SELECT COUNT(*) FROM imported_files WHERE nombre_archivo = ?");
                check.setString(1, nombreArchivo);
                ResultSet rs = check.executeQuery();
                rs.next();
                if (rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(this, "Este archivo ya fue cargado.");
                    return;
                }

                // Insertar archivo
                PreparedStatement psArchivo = conn.prepareStatement(
                        "INSERT INTO imported_files (nombre_archivo, fecha_carga, estado) VALUES (?, ?, ?)");
                psArchivo.setString(1, nombreArchivo);
                psArchivo.setDate(2, fechaHoy);
                psArchivo.setString(3, "Procesando");
                psArchivo.executeUpdate();

                // Insertar usuarios
                BufferedReader br = new BufferedReader(new FileReader(archivo));
                PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO migrated_users (id_mu, full_name_mu, email_mu, phone_mu, birth_date_mu, import_date_mu) VALUES (?, ?, ?, ?, ?, ?)");
                String linea;
                int count = 0;
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                br.readLine(); // saltar encabezado

                while ((linea = br.readLine()) != null) {
                    String[] datos = linea.split(",");
                    if (datos.length >= 6) {
                        try {
                            ps.setInt(1, Integer.parseInt(datos[0].trim()));
                            ps.setString(2, datos[1].trim());
                            ps.setString(3, datos[2].trim());
                            ps.setString(4, datos[3].trim());
                            java.util.Date birth = sdf.parse(datos[4].trim());
                            java.util.Date importDate = sdf.parse(datos[5].trim());
                            ps.setDate(5, new java.sql.Date(birth.getTime()));
                            ps.setDate(6, new java.sql.Date(importDate.getTime()));
                            ps.addBatch();
                            count++;
                        } catch (Exception ex) {
                            System.out.println("Línea con error: " + linea);
                        }
                    }
                }

                ps.executeBatch();
                br.close();
                ps.close();

                // Actualizar estado
                PreparedStatement psEstado = conn.prepareStatement(
                        "UPDATE imported_files SET estado = 'Completado' WHERE nombre_archivo = ?");
                psEstado.setString(1, nombreArchivo);
                psEstado.executeUpdate();
                psEstado.close();

                conn.commit();
                JOptionPane.showMessageDialog(this, "Archivo cargado con " + count + " registros.");
                cargarArchivosDesdeBD();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }
    }

    private void cargarArchivosDesdeBD() {
        model.setRowCount(0);
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT nombre_archivo, fecha_carga, estado FROM imported_files";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String nombre = rs.getString("nombre_archivo");
                Date fecha = rs.getDate("fecha_carga");
                String estado = rs.getString("estado");

                JButton btnVer = new JButton("Ver");
                btnVer.setBackground(new Color(65, 105, 225));
                btnVer.setForeground(Color.WHITE);

                JButton btnEliminar = new JButton("Eliminar");
                btnEliminar.setBackground(new Color(70, 130, 180));
                btnEliminar.setForeground(Color.WHITE);

                btnVer.addActionListener(e -> mostrarContenidoArchivo(nombre));
                btnEliminar.addActionListener(e -> {
                    int confirm = JOptionPane.showConfirmDialog(this,
                        "¿Estás seguro que deseas eliminar \"" + nombre + "\"?",
                        "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        eliminarArchivo(nombre);
                    }
                });

                JPanel panelAcciones = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
                panelAcciones.add(btnVer);
                panelAcciones.add(btnEliminar);

                model.addRow(new Object[]{nombre, fecha, estado, panelAcciones});
            }

            rs.close();
            stmt.close();

            table.getColumn("Estado").setCellRenderer(new DefaultTableCellRenderer() {
                public void setValue(Object value) {
                    setText(value.toString());
                    if ("Completado".equalsIgnoreCase(value.toString())) {
                        setForeground(new Color(0, 153, 0));
                    } else {
                        setForeground(Color.GRAY);
                    }
                }
            });

            table.getColumn("Acciones").setCellRenderer((table, value, isSelected, hasFocus, row, column) -> (Component) value);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar archivos: " + e.getMessage());
        }
    }

    private void mostrarContenidoArchivo(String nombreArchivo) {
        JFrame frame = new JFrame("Contenido de " + nombreArchivo);
        frame.setSize(700, 300);
        frame.setLocationRelativeTo(this);

        JTable tabla = new JTable();
        DefaultTableModel modelo = new DefaultTableModel(new Object[]{
            "ID", "Nombre", "Email", "Teléfono", "Nacimiento", "Importación"
        }, 0);
        tabla.setModel(modelo);

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT mu.* FROM migrated_users mu " +
                         "JOIN imported_files f ON mu.import_date_mu = f.fecha_carga " +
                         "WHERE f.nombre_archivo = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nombreArchivo);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id_mu"),
                    rs.getString("full_name_mu"),
                    rs.getString("email_mu"),
                    rs.getString("phone_mu"),
                    rs.getDate("birth_date_mu"),
                    rs.getDate("import_date_mu")
                });
            }

            rs.close();
            ps.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al mostrar archivo: " + ex.getMessage());
        }

        frame.add(new JScrollPane(tabla));
        frame.setVisible(true);
    }

    private void eliminarArchivo(String nombreArchivo) {
        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement fechaStmt = conn.prepareStatement(
                    "SELECT fecha_carga FROM imported_files WHERE nombre_archivo = ?");
            fechaStmt.setString(1, nombreArchivo);
            ResultSet rs = fechaStmt.executeQuery();

            java.sql.Date fecha = null;
            if (rs.next()) fecha = rs.getDate(1);
            rs.close();
            fechaStmt.close();

            if (fecha != null) {
                PreparedStatement delMu = conn.prepareStatement(
                        "DELETE FROM migrated_users WHERE import_date_mu = ?");
                delMu.setDate(1, fecha);
                delMu.executeUpdate();
                delMu.close();
            }

            PreparedStatement delArchivo = conn.prepareStatement(
                    "DELETE FROM imported_files WHERE nombre_archivo = ?");
            delArchivo.setString(1, nombreArchivo);
            delArchivo.executeUpdate();
            delArchivo.close();

            JOptionPane.showMessageDialog(this, "Archivo eliminado.");
            cargarArchivosDesdeBD();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GestorArchivosFrame().setVisible(true));
    }
}